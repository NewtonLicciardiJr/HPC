Hands-on “Working with Intel Xeon and Intel Xeon Phi Architecture” 
